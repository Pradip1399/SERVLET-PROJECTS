package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.*;

public class FirstServlet implements Servlet{
    
    ServletConfig conf;
    
    //Life Cycle Methods
    @Override
    public void init(ServletConfig conf)
    {
        this.conf=conf;
        System.out.println("Creating object");
    }
    
    @Override
    public void service(ServletRequest req, ServletResponse resp) throws IOException, ServletException
    {
        System.out.println("servicing");
        
        //set the contetnt type of the response
            resp.setContentType("text/html");
            PrintWriter out = resp.getWriter();
            
            out.println("<h1>This is output from first servlet method");
            out.println("<h1>Current time is : " + new Date().toString() + "</h1>");
        
    }
    
    @Override
    public void destroy()
    {
        System.out.println("destroying servlet object");
    }
    
    
    //Non Life Cycle methods
    @Override
    public ServletConfig getServletConfig()
    {
        return this.conf;
    }
    
    @Override
    public String getServletInfo()
    {
        return "this servlet is created by me";
    }
}

