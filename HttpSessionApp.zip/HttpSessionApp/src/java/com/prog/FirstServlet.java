package com.prog;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "SeconServlet2", urlPatterns = {"/SeconServlet2"})
public class FirstServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name = request.getParameter("nm");
        
        response.setContentType("text/html");
        
        PrintWriter out = response.getWriter();
        
        out.print("<h1>Name : "+ name + "</h1>");
        
        HttpSession session = request.getSession();
        session.setAttribute("username", name);
        
        out.println("<a href='SecondServlet'>Servlet 2</a>");
        
    }

}
